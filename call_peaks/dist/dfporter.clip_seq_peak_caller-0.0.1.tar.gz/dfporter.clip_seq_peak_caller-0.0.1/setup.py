from setuptools import setup, find_packages

PACKAGE = 'clip_seq_peak_caller'
desc_lines = open('README', 'r').readlines()

setup(name="dfporter.%s" % PACKAGE,
	version = "0.0.1",
	author = "Douglas Porter",
	author_email = "dfporter@wisc.edu",
	description = ("Experimental CLIP-seq peak caller program."),
	long_description = ''.join(desc_lines),
	license = "MIT",
	packages = find_packages(),
	classifiers=['Development Status :: 2 - Pre-Alpha',
	'License :: OSI Approved :: MIT License',
 	'Programming Language :: Python :: 2.7',
	],
	keywords='clip_seq HITS',
)


